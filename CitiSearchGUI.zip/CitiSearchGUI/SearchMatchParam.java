public class SearchMatchParam{
	public boolean active;
	public String value;

	SearchMatchParam()
	{
		
	}

	SearchMatchParam(boolean act, String val)
	{
		active = act;
		value = val;
	}

	public void print(String name){
		System.out.println(name + ' ' + active + ' ' + value);
	}
}