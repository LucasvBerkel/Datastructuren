public class DefSearch{
	MyCitySearch searchCountry; 
	MyCitySearch searchLatitude; 
	MyCitySearch searchLongitude; 
	MyCitySearch searchPopulation;
	MyCitySearch searchElevation; 
	MyCity[] m_database;

	DefSearch(MyCity[] database){
		searchCountry = new MyCitySearch(database, enums.Key.COUNTRY);
		searchLatitude = new MyCitySearch(database, enums.Key.LATITUDE);
		searchLongitude = new MyCitySearch(database, enums.Key.LONGITUDE);
		searchPopulation = new MyCitySearch(database, enums.Key.POPULATION);
		searchElevation = new MyCitySearch(database, enums.Key.ELEVATION);
	}

	public MyResults search(DefSearchParam parameters){
		MyResults results = null;

		if (parameters.landcode.active){
			results = searchCountry.search(parameters.landcode.value);
		}
		if (parameters.latitude.active){
			
		}
		if (parameters.longitude.active){
			
		}
		if (parameters.population.active){
			
		}
		if (parameters.elevation.active){
			
		}		

		return results;
	}
}