import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;

public class DefaultSearchPanel extends JPanel implements ICallback{
	final String name = "Default Search";

	DefSearch m_search;
	ResultsPanel m_results;

	JRadioButton m_landcode;
	JRadioButton m_latitude;
	JRadioButton m_longitude;
	JRadioButton m_population;
	JRadioButton m_elevation;

	JComboBox m_landcode_sel;

	JTextField m_latitude_min;
	JTextField m_longitude_min;
	JTextField m_population_min;
	JTextField m_elevation_min;

	JTextField m_latitude_max;
	JTextField m_longitude_max;
	JTextField m_population_max;
	JTextField m_elevation_max;	


	DefaultSearchPanel(DefSearch search, ResultsPanel results){
		super(new GridBagLayout());

		m_search = search;
		m_results = results;

		String[] landcodes = new String[3];
		landcodes[0] = "NL";
		landcodes[1] = "DE";
		landcodes[2] = "US";

		InitPane0(landcodes);
		InitPane1();
		InitPane2();

		GridBagConstraints constraint;
		constraint = new GridBagConstraints();
	    constraint.weightx = 0.5;
	    constraint.weighty = 1;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 0;
	    constraint.gridy = 8;
	    constraint.ipady = 20;
	    add(new JLabel(""), constraint);

		Button searchButton = new Button("Search", this);
		constraint = new GridBagConstraints();
	    constraint.weightx = 0.5;
	    constraint.weighty = 0;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 0;
	    constraint.gridy = 9;		
		add(searchButton, constraint);
	}

	private void InitPane0(String[] landcodes){
		m_landcode_sel = new JComboBox(landcodes);

		m_latitude_min = new JTextField(10);
		m_longitude_min = new JTextField(10);
		m_population_min = new JTextField(10);
		m_elevation_min = new JTextField(10);

		GridBagConstraints constraint;
		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 0;
	    constraint.gridy = 0;
		add(new JLabel("Select Landcode:"), constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 0;
	    constraint.gridy = 1;
		add(m_landcode_sel, constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 0;
	    constraint.gridy = 2;
	    constraint.ipady = 20;
		add(new JLabel(""), constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 0;
	    constraint.gridy = 3;
		add(new JLabel("  Min values:"), constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 0;
	    constraint.gridy = 4;
		add(m_latitude_min, constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 0;
	    constraint.gridy = 5;
		add(m_longitude_min, constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 0;
	    constraint.gridy = 6;
		add(m_population_min, constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 0;
	    constraint.gridy = 7;
		add(m_elevation_min, constraint);
	}

	private void InitPane1(){
		m_latitude_max = new JTextField(10);
		m_longitude_max = new JTextField(10);
		m_population_max = new JTextField(10);
		m_elevation_max = new JTextField(10);

		GridBagConstraints constraint;
		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 1;
	    constraint.gridy = 2;
	    constraint.ipady = 20;
		add(new JLabel(""), constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 1;
	    constraint.gridy = 3;
		add(new JLabel("Max values:"), constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 1;
	    constraint.gridy = 4;
		add(m_latitude_max, constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 1;
	    constraint.gridy = 5;
		add(m_longitude_max, constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 1;
	    constraint.gridy = 6;
		add(m_population_max, constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 1;
	    constraint.gridy = 7;
		add(m_elevation_max, constraint);
	}

	private void InitPane2(){
		m_landcode = new JRadioButton("Landcodes");
		m_latitude = new JRadioButton("Latitude");
		m_longitude = new JRadioButton("Longitude");
		m_population = new JRadioButton("Population");
		m_elevation = new JRadioButton("Elevation");

		GridBagConstraints constraint;
		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 2;
	    constraint.gridy = 1;
		add(m_landcode, constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 1;
	    constraint.gridy = 2;
	    constraint.ipady = 20;
		add(new JLabel(""), constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 2;
	    constraint.gridy = 4;
		add(m_latitude, constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 2;
	    constraint.gridy = 5;
		add(m_longitude, constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 2;
	    constraint.gridy = 6;
		add(m_population, constraint);

		constraint = new GridBagConstraints();
		constraint.weightx = 0.5;
	    constraint.weighty = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 2;
	    constraint.gridy = 7;
		add(m_elevation, constraint);
	}

	public void callback(String source){
		DefSearchParam parameters = new DefSearchParam();

		parameters.landcode = new SearchMatchParam(m_landcode.isSelected(), 
												   (String)m_landcode_sel.getSelectedItem());
		parameters.latitude = new SearchRangeParam(m_latitude.isSelected(), 
												   m_latitude_min.getText(), 
												   m_latitude_max.getText());
		parameters.longitude = new SearchRangeParam(m_longitude.isSelected(), 
												   m_longitude_min.getText(), 
												   m_longitude_max.getText());
		parameters.population = new SearchRangeParam(m_population.isSelected(), 
												   m_population_min.getText(), 
												   m_population_max.getText());
		parameters.elevation = new SearchRangeParam(m_elevation.isSelected(), 
												   m_elevation_min.getText(), 
												   m_elevation_max.getText());	


		MyResults results = m_search.search(parameters);

		if (results != null)
		{
			m_results.set(results);
		}
	}


}