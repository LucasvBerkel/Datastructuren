public class AdvSearch{
	AdvSearch(MyCity[] database){
	}

	public MyResults search(DefSearchParam parameters){	
		return null;
	}
}