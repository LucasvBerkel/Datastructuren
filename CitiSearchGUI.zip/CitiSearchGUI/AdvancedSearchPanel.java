import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;

public class AdvancedSearchPanel extends JPanel{
	final String name = "Advanced Search";

	AdvancedSearchPanel(AdvSearch adv, ResultsPanel results){
	}
}