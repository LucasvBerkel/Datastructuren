public class MyCityLink{
	public int index;
	public int value_int;
	public String value_string;
}