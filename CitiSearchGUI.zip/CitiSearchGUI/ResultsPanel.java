import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.table.*;
import javax.swing.border.*;

public class ResultsPanel extends JPanel{
	final String name = "Results";

	Table m_table;

	ResultsPanel(){
		super(new GridBagLayout());

		GridBagConstraints constraint;
		constraint = new GridBagConstraints();
	    constraint.weightx = 0.5;
	    constraint.fill = GridBagConstraints.HORIZONTAL;
	    constraint.gridx = 0;
	    constraint.gridy = 0;
	    add(new JLabel("Cities"), constraint);

		constraint = new GridBagConstraints();
	    constraint.weightx = 0.5;
	    constraint.weighty = 1;
	    constraint.fill = GridBagConstraints.BOTH;
	    constraint.gridx = 0;
	    constraint.gridy = 1;

	    String[] header = {"Cities"};
		DefaultTableModel tableModel = new DefaultTableModel(null, header);
		m_table = new Table(tableModel);
		add(m_table, constraint);
	}

	// data in tabel krijgen werkt nog niet.
	public void set(MyResults results){
	    String[] header = {"Cities"};
	    String[][] data = results.table();

	    for (int i = 0; i < data.length; i++)
	    {
	    	System.out.println(data[i][0]);
	    }

		DefaultTableModel tableModel = new DefaultTableModel(data, header);
		m_table = new Table(tableModel);
	}
}