public class enums{
		public enum Key{
		LATITUDE, 
		LONGITUDE,
		COUNTRY,
		POPULATION,
		ELEVATION
	}
}