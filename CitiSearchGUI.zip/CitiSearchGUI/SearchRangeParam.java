import java.io.*;
import java.util.*;
import java.lang.*;

public class SearchRangeParam{
	public boolean active;
	public String min, max;

	SearchRangeParam()
	{

	}

	SearchRangeParam(boolean act, String minValue, String maxValue)
	{
		active = act;
		min = minValue;
		max = maxValue;
	}

	public void print(String name){
		System.out.println(name + ' ' + active + ' ' + min + ' ' + max);
	}
}