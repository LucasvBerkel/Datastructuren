public class DefSearchParam{
	public SearchMatchParam landcode;
	public SearchRangeParam latitude;
	public SearchRangeParam longitude;
	public SearchRangeParam population;
	public SearchRangeParam elevation;

	public void print(){
		landcode.print("Landcode: ");
		latitude.print("latitude: ");
		longitude.print("longitude: ");
		population.print("population: ");
		elevation.print("elevation: ");
	}
}